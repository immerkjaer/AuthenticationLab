package src;

public enum Status {
    Printing,
    Ready,
    Stopped
}
